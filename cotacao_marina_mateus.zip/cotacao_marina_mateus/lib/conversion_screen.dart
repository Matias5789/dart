import 'package:flutter/material.dart';
import 'services/api_service.dart';
import 'services/storage_service.dart';

class ConversionScreen extends StatefulWidget {
  @override
  _ConversionScreenState createState() => _ConversionScreenState();
}

class _ConversionScreenState extends State<ConversionScreen> {
  final _btcController = TextEditingController();
  double? _convertedValue;
  String _selectedCurrency = 'USD';

  @override
  void initState() {
    super.initState();
    // Carregar a última moeda selecionada do armazenamento
    StorageService.getSelectedCurrency().then((currency) {
      setState(() {
        _selectedCurrency = currency ?? 'USD';
      });
    });
  }

  void _convert() async {
    if (_btcController.text.isNotEmpty) {
      double btcAmount = double.parse(_btcController.text);
      double conversionRate =
          await ApiService.getBtcConversionRate(_selectedCurrency);
      setState(() {
        _convertedValue = btcAmount * conversionRate;
      });

      // Salvar consulta no histórico
      StorageService.saveConversion(
          btcAmount, _selectedCurrency, _convertedValue!);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Conversão de BTC'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _btcController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Quantos BTC?',
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _convert,
              child: Text('Converter'),
            ),
            SizedBox(height: 20),
            if (_convertedValue != null)
              Text(
                'Valor convertido: ${_convertedValue?.toStringAsFixed(2)} $_selectedCurrency',
                style: TextStyle(fontSize: 20),
              ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Conversão',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.history),
            label: 'Histórico',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Configurações',
          ),
        ],
        onTap: (index) {
          if (index == 1) {
            Navigator.pushNamed(context, '/history');
          } else if (index == 2) {
            Navigator.pushNamed(context, '/settings');
          }
        },
      ),
    );
  }
}
