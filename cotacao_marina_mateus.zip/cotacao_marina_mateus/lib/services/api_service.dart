import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static Future<double> getBtcConversionRate(String currency) async {
    final response = await http.get(Uri.parse(
        'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=$currency'));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return data['bitcoin'][currency.toLowerCase()] as double;
    } else {
      throw Exception('Falha ao carregar a cotação');
    }
  }
}
