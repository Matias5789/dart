import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  static Future<void> saveConversion(
      double btcAmount, String currency, double convertedValue) async {
    final prefs = await SharedPreferences.getInstance();
    List<String> history = prefs.getStringList('conversion_history') ?? [];
    history.add('$btcAmount BTC = $convertedValue $currency');
    await prefs.setStringList('conversion_history', history);
  }

  static Future<List<String>> getConversionHistory() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList('conversion_history') ?? [];
  }

  static Future<void> saveSelectedCurrency(String currency) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('selected_currency', currency);
  }

  static Future<String?> getSelectedCurrency() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('selected_currency');
  }
}
