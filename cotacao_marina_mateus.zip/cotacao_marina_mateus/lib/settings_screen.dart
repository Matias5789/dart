import 'package:flutter/material.dart';
import 'services/storage_service.dart';

class SettingsScreen extends StatefulWidget {
  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _selectedCurrency = 'USD';

  @override
  void initState() {
    super.initState();
    // Carregar a última moeda selecionada
    StorageService.getSelectedCurrency().then((currency) {
      setState(() {
        _selectedCurrency = currency ?? 'USD';
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Configurações'),
      ),
      body: ListView(
        children: [
          ListTile(
            title: Text('Selecione a moeda'),
            trailing: DropdownButton<String>(
              value: _selectedCurrency,
              onChanged: (String? newValue) {
                setState(() {
                  _selectedCurrency = newValue!;
                });
                StorageService.saveSelectedCurrency(_selectedCurrency);
              },
              items: <String>['USD', 'EUR', 'BRL']
                  .map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}
