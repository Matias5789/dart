package com.example.cotacao_marina_mateus

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
